package suchen.al;

import suchen.bl.Produktinformation;

public interface PruefeWare {
    Produktinformation holeDetailinformation(String warenname);
}
