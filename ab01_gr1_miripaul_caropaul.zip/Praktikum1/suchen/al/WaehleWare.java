package suchen.al;

public interface WaehleWare {
    boolean wareZuWarenkorbHinzufuegen(String warenname);
}
