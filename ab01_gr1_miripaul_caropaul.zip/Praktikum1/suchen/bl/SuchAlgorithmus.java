package suchen.bl;

public enum SuchAlgorithmus {
    KeywordMatching, SemanticMatching;

}
