package suchen.bl;

public class Geld {
    float betrag;

    public Geld(float betrag){
        this.betrag = betrag;
    }
}
