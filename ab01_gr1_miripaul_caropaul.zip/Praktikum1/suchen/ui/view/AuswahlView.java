package suchen.ui.view;


public class AuswahlView {
    public void printAuswahlMenue(){
        System.out.println("1. Artikel zum Warenkorb hinzufuegen.");
        System.out.println("2. Menue");
    }

    public void artikelNameEingeben(){
        System.out.println("Gib den Namen des Artikels ein, den du deinem Warenkorb hinzufuegen willst: \n");
    }
}
