package suchen.ui.view;

public class MainView {
    public void printSucheStart(){
        System.out.println("------ Suche ------");
        System.out.println("1. Suchen");
        System.out.println("2. Zurück");
    }

    public void printPruefenOderAuswahl(){
        System.out.println("1. Artikel zum Warenkorb hinzufuegen");
        System.out.println("2. Produktinformationen anzeigen");
    }
}
