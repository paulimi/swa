package suchen.acl;


public class WarenkorbVerwalten {

  
    public boolean wareZuWarenkorbHinzufuegen(WareDTO wareDTO) {
        System.out.println("Artikel wurde dem Warenkorb hinzugefuegt!");
        return true;
    }
    
}
