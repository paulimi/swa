package ui.view;

public class MenueView {

    public void printMenue(){
        System.out.println("------ Menue ------");
        System.out.println("1. Artikel suchen");
        System.out.println("2. Warenkorb ansehen");
        System.out.println("3. Zur Kasse gehen");
        System.out.println("4. Abmelden");
        System.out.println("Was willst du machen?");
    }
}
