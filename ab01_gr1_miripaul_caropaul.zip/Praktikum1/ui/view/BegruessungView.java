package ui.view;

public class BegruessungView {
    public void printBegruessung(){
        System.out.println("------ Willkommen in der SimpleShoppingApp ------");
    }

}
